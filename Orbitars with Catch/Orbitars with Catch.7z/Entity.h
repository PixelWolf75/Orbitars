#pragma once
#include <windows.h>
#include "Universal_Structures.h"
#include <Unknwn.h> 
#include <objidl.h>
#include <gdiplus.h>
#include <map>
#include <string>
#include "GameState.h"


struct point_t {
	float fx;
	float fy;
};
inline point_t operator+=(point_t A, point_t B) {
	return { (A.fx + B.fx), (A.fy + B.fy) };
}

class Entity
{
public:
	Entity(point_t fPos_, point_t fVec_, float fRotation_, RECT rcHitbox_)
		: fPos(fPos_)
		, fVec(fVec_)
		, fRotation(fRotation_)
		, rcHitBox(rcHitbox_)
	{

	}

	point_t fPos; // Determines the position of the entity relative to the screen
	point_t fVec; // Determines the velocity of the entity which affects how much the position is changed
	float fRotation; // Determines the rotation of the entity
	RECT rcHitBox; // Determines the area that the entity exists

	virtual void Render_Entity(HWND hWnd, HDC hdc, GameState::map_o_images_t*); //Renders the entity
	virtual void Update_Entity(HWND hWnd, POINT ptCursorPos); //Updates the entity
	virtual void Input_Entity(eKeyboard eKey_press);
};