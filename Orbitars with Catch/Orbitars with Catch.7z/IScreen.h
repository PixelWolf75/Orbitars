#pragma once
#include <memory>
#include <string>
#include "GameState.h"
#include <functional>
#include <Windows.h>
#include "Universal_Structures.h"


namespace CODE {

	namespace SCREENS {

		namespace ENUMS {



			enum eScreen_Type {
				Splash = 0,
				Main,
				Options
			};
		}

		namespace Objects {

			class IScreen {
			public:
				virtual void Render(HWND hWnd, HDC hdc) = 0;
				virtual void Update(HWND hWnd, POINT ptCursor) = 0;
				virtual void Input(eKeyboard) = 0;
			};

			typedef std::unique_ptr<GameState> game_state_t;
			typedef std::unique_ptr<IScreen> screen_t;
			typedef std::function<screen_t(game_state_t sGame)> screen_callback_t;


			class ScreenController
			{
			public:

				//gets the current screen
				static IScreen* get();

				//Renders the screen
				static void Render(HWND hWnd, HDC hdc);

				//Updates the screen a certain amount of times per frame
				static void Update(HWND hWnd, POINT ptCursor);

				static void Input(eKeyboard eKeyPress);

				//Changes which screen we're on
				static void set_screen(const char* szName, game_state_t sGame);

				static void Record(const char* szName, screen_callback_t);
			};
		}

	}
}
