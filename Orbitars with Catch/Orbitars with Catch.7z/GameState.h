#pragma once
#include <memory>
#include <string>
#include <functional>
#include <Unknwn.h>    
#include <windows.h>
#include <gdiplus.h>
#include <objidl.h>
#include <map>


struct GameState {
	int iPort;
	int type;
	typedef std::map<std::string, std::unique_ptr<Gdiplus::Image>> map_o_images_t;
	
	map_o_images_t mapImgFiles;


	GameState(int iPort_, int iType_)
		: iPort(iPort_)
		, type(iType_)
	{
		

	}
};

