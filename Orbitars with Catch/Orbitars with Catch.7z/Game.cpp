#include "IScreen.h"
#include <vector>
#include <map>
#include <gdiplus.h>
#include "Player.h"

using namespace CODE;
using namespace CODE::SCREENS;
using namespace CODE::SCREENS::Objects;
using namespace std;
using namespace Gdiplus;

class Game : public IScreen
{
public:
	Game(game_state_t&& pSomething_);
	~Game();

	virtual void Render(HWND hWnd, HDC hdc) override; // Renders the game
	virtual void Update(HWND hWnd, POINT ptCursor) override; // Updates the game based on frame rate
	virtual void Input(eKeyboard eKey_press) override;

	void Bullet_Check(map<size_t, Player> mapPlayers, Player* it); //Checks to see if the bullets hit anything

	map<size_t, Player> mapPlayers; //Players organised by IDs
	int ID;
	int iPlayer_Count;
	game_state_t pGameInfo;
};

//Called first upon creation
//Creates the Game screen record
static int auto_registration() {
	ScreenController::Record("Game", [](game_state_t&& pSomething) -> screen_t {
		return std::make_unique<Game>(move(pSomething));
		});
	return 0;
}

static int g_Register = auto_registration();

Game::Game(game_state_t&& pSomething_)
	: ID(0)
	, iPlayer_Count(0)
	, pGameInfo(std::move(pSomething_))
{

	Player default_Player = Player({ 100.0f, 100.0f }, { 0.0f, 0.0f }, 0, { 0,0, 25, 25 }, 0, false);
	mapPlayers.insert(std::pair<size_t, Player>(0, default_Player));

	iPlayer_Count = mapPlayers.size();
}

Game::~Game() {

}

bool operator==(point_t A, point_t B)
{
	return (A.fx == B.fy) && (A.fy == B.fy);
}

void Game::Render(HWND hWnd, HDC hdc)
{
	// renders the screen
	//tells players to render
	//tells bullets to render
	for (auto it = mapPlayers.begin(); it != mapPlayers.end(); it++)
	{
		it->second.Render_Entity(hWnd, hdc, &pGameInfo->mapImgFiles);
	}
}

//Checks to see if the bullets hit anything
//mapPlayers: the map to the player to alter the player connected to the bullet
//it: the pointer to the player that fired the bullets
void Game::Bullet_Check(map<size_t, Player> mapPlayers, Player* it)
{
	//For every bullet
	for (auto itBullet = it->vecBullets.begin(); itBullet != it->vecBullets.end(); itBullet++)
	{
		//Checks every player
		for (auto it2 = (mapPlayers).begin(); it2 != (mapPlayers).end(); it2++)
		{
			//If its touching the player who fired it skip
			if (it2->second.ID == it->ID)
			{
				continue;
			}
			//If the player gets hit take damage
			if (it2->second.fPos == itBullet->fPos)
			{
				it2->second.Player_taken_damage();
				it->iScore++;
			}

			//If a player has been killed
			if (it2->second.bIsAlive == false)
			{
				//mapPlayers.erase(it2);
				it->iScore += 10;
				iPlayer_Count--;
				if (iPlayer_Count <= 1)
				{
					//end game;
				}
			}
		}
	}
}

void Game::Update(HWND hWnd, POINT ptCursor)
{
	//Updates the position of the player based on the input
	//Updates the player position based on gravitational constant

	for (auto it = mapPlayers.begin(); it != mapPlayers.end(); it++)
	{
		it->second.Update_Entity(hWnd, ptCursor);

		Bullet_Check(mapPlayers, &it->second);
	}
}

void Game::Input(eKeyboard eKey_press)
{
	//Input command based onplayer based on ID
	//When server is implemented make it so that this sends a packet with input
	mapPlayers.at(ID).Input_Entity(eKey_press);
}