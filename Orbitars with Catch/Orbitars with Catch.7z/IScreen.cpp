#include "IScreen.h"
#include <mutex>
#include <map>
#include <string>
#include <vector>
#include "IStars.h"
using namespace std;
using namespace CODE;
using namespace CODE::SCREENS;
using namespace CODE::SCREENS::Objects;
using CODE::SCREENS::Objects::ScreenController;

static IStars* g_pStar = new IStars();

static map<string, CODE::SCREENS::Objects::screen_callback_t>* g_pCallbacks = nullptr;
static screen_t g_current_screen;
static vector<screen_t> g_deleted_screens;
static std::recursive_mutex g_current_screen_mutex;

IScreen* ScreenController::get()
{
	return g_current_screen.get();
}

void CODE::SCREENS::Objects::ScreenController::Render(HWND hWnd, HDC hdc)
{
	std::lock_guard<std::recursive_mutex>Guard(g_current_screen_mutex);
	g_pStar->Render(hdc, hWnd);
	g_current_screen->Render(hWnd, hdc);
}

void CODE::SCREENS::Objects::ScreenController::Update(HWND hWnd, POINT ptCursor)
{
	std::lock_guard<std::recursive_mutex>Block(g_current_screen_mutex);
	g_pStar->Update(hWnd);
	g_current_screen->Update(hWnd, ptCursor);
	g_deleted_screens.clear();

}

void CODE::SCREENS::Objects::ScreenController::Input(eKeyboard eKeyPress)
{
	std::lock_guard<std::recursive_mutex>Block(g_current_screen_mutex);
	g_current_screen->Input(eKeyPress);
}

void CODE::SCREENS::Objects::ScreenController::set_screen(const char* szName, game_state_t sGame)
{
	if (!g_pCallbacks)
	{
		throw new runtime_error("Failed to intiallise g_pCallbacks");
	}
	auto it = g_pCallbacks->find(szName);
	if (it == g_pCallbacks->end())
	{
		throw new runtime_error(string("Unknown Screen requested"));
	}

	std::lock_guard<std::recursive_mutex>Block(g_current_screen_mutex);

	g_deleted_screens.emplace_back(move(g_current_screen));

	g_current_screen = it->second(move(sGame));
}

void CODE::SCREENS::Objects::ScreenController::Record(const char* szName, screen_callback_t callback)
{
	// Singleton pointer is nullptr at start
	if (!g_pCallbacks)
	{
		g_pCallbacks = new map<string, screen_callback_t>();
	}

	g_pCallbacks->insert(pair<string, screen_callback_t>(string(szName), callback));
}
