#include "IScreen.h"
#include <string>
#include <vector>

#define TEXT_WIDTH_DISTANCE 200
#define TEXT_HEIGHT_DISTANCE 150

using namespace std;
using namespace CODE;
using namespace CODE::SCREENS;
using namespace CODE::SCREENS::Objects;


class Main : public IScreen
{
public:
	Main(game_state_t&& pStuff);
	~Main();

	void Render(HWND hWnd, HDC hdc) override;
	void Update(HWND hWnd, POINT ptCursor) override;
	void Input(eKeyboard) override;

	bool bUpdate;
	game_state_t pCommon;
	vector<string> vecOptions;

	vector<RECT> vecRects;

	size_t pos;
	DWORD Tick;

	bool bQuit;

};

static int auto_registration() {
	ScreenController::Record("Main", [](game_state_t&& pSomething) -> screen_t {
		return std::make_unique<Main>(move(pSomething));
		});
	return 0;
}

static int g_Register = auto_registration();


Main::Main(game_state_t&& pStuff)
	: pCommon(move(pStuff))
	, vecOptions({ "Option1", "Option2", "Quit" })
	, pos(0)
	, bUpdate(true)
	, bQuit(false)
	, Tick(0)
{
	for (size_t i = 0; i < vecOptions.size(); i++)
	{
		vecRects.push_back(RECT({ LONG(80), LONG(200*(i+1)), LONG(20000), LONG((i + 2) * 200) }));
	}
}

Main::~Main()
{
}

void Main::Render(HWND hWnd, HDC hdc)
{
	RECT rc;
	GetClientRect(hWnd, &rc);
	//InvalidateRect(hWnd, &rc, false);

	SetTextColor(hdc, RGB(255, 255, 255));
	SetBkMode(hdc, TRANSPARENT);
	RECT rect = { 40, 40, rc.right, rc.bottom };
	HFONT font = CreateFontA(80, 0, 0, 0, 80, false, false, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, "Arial");
	HFONT hFontOld = (HFONT)SelectObject(hdc, font);
	DrawTextA(hdc, "Menu:", -1, &rect, DT_SINGLELINE | DT_NOCLIP);
	rect.top = 200;
	rect.left = 80;
	int iLineHeight = 200;

	for (size_t i = 0; i < vecOptions.size(); i++)
	{
		rect.top = 200 + ( i * iLineHeight);

		if (i == pos)
		{
			rect.left = 80;
			DrawTextA(hdc, string(">" + vecOptions[i]).c_str(), -1, &rect, DT_NOCLIP);
		}
		else {
			rect.left = 160;
			DrawTextA(hdc, string(vecOptions[i]).c_str(), -1, &rect, DT_NOCLIP);
		}
	}

	SelectObject(hdc, hFontOld);
	DeleteObject(font);


}

void Main::Update(HWND hWnd, POINT ptCursor)
{
	//Check cursor position
	POINT ptScreenCursor = ptCursor;
	if (ScreenToClient(hWnd, &ptScreenCursor))
	{

		if (ptScreenCursor.x >= 80 && ptScreenCursor.y >= 200 && ptScreenCursor.y <= (vecOptions.size() + 1) * 200)
		{
			for (size_t i = 0; i < vecRects.size(); i++)
			{
				if (ptCursor.y >= vecRects[i].top && ptCursor.y <= vecRects[i].bottom)
				{
					pos = i;

					bUpdate = true;
				}
			}
		}
	}


	if (bQuit)
	{
		DestroyWindow(hWnd);
	}
}

void Main::Input(eKeyboard eKey_press)
{
	switch (eKey_press)
	{
	case Down:
		if (pos < (vecOptions.size() - 1))
		{
			pos++;
			//bUpdate = true;
		}
		break;
	case Up:
		if (pos > 0)
		{
			pos--;
			//bUpdate = true;
		}
		break;
	case Enter:
	case Left_Click:
		if (vecOptions[pos] == "Option1")
		{

		}
		else if (vecOptions[pos] == "Option2")
		{

		}
		else if (vecOptions[pos] == "Quit")
		{
			bQuit = true;
		}
		break;
	default:
		break;
	}
}