#include "Entity.h"

void Entity::Render_Entity(HWND hWnd, HDC hdc, GameState::map_o_images_t*)
{
}

void Entity::Update_Entity(HWND hWnd, POINT ptCursorPos)
{
}

void Entity::Input_Entity(eKeyboard eKey_press)
{
}


